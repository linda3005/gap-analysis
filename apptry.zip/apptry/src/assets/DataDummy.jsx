const DataDummy = [
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Good",
        "tanggal": "2023",
        "jam": "14:30",
        "__v": 0
    },
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Poor",
        "tanggal": "2023",
        "jam": "14:30",
        "__v": 0
    },
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Excellent",
        "tanggal": "2023",
        "jam": "14:30",
        "__v": 0
    },
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Good",
        "tanggal": "2023",
        "jam": "14:30",
        "__v": 0
    },
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Poor",
        "tanggal": "2022",
        "jam": "14:30",
        "__v": 0
    },
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Excellent",
        "tanggal": "2022",
        "jam": "14:30",
        "__v": 0
    },
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Good",
        "tanggal": "2022",
        "jam": "14:30",
        "__v": 0
    },
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Poor",
        "tanggal": "2021",
        "jam": "14:30",
        "__v": 0
    },
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Excellent",
        "tanggal": "2021",
        "jam": "14:30",
        "__v": 0
    },
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Good",
        "tanggal": "2020",
        "jam": "14:30",
        "__v": 0
    },
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Poor",
        "tanggal": "2020",
        "jam": "14:30",
        "__v": 0
    },
    {
        "_id": "6554832c4eedd3986ce99b5a",
        "kodeLoko": "LOKOLOKOLOKO12",
        "namaLoko": "Loko ABC",
        "dimensiLoko": "10x5",
        "status": "Excellent",
        "tanggal": "2020",
        "jam": "14:30",
        "__v": 0
    },
]

export default DataDummy