
const DashboardHeader = () => {
  return <header>Dashboard Header</header>;
};

export default DashboardHeader;
