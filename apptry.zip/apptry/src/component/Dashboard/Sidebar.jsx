
const Sidebar = () => {
  return <aside>Sidebar</aside>;
};

export default Sidebar; 



